import { useState, useEffect } from 'react';
import { useRoute } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, Trash2, Save, ArrowLeft, Video, Package, Wrench, Eye, EyeOff,
  Layout, Type, Image as ImageIcon, FileText, Star, Users, DollarSign,
  Move, Settings, Copy, ChevronUp, ChevronDown, Palette, Monitor,
  HelpCircle, ArrowRight, Shield
} from 'lucide-react';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { Game } from '@shared/schema';

// Component types for the page builder
interface PageSection {
  id: string;
  type: 'hero' | 'features' | 'pricing' | 'gallery' | 'testimonials' | 'faq' | 'cta' | 'specs';
  title: string;
  content: any;
  style: {
    backgroundColor: string;
    textColor: string;
    padding: string;
    layout: string;
  };
  order: number;
}

const defaultSections: Record<string, Omit<PageSection, 'id' | 'order'>> = {
  hero: {
    type: 'hero',
    title: 'Hero Section',
    content: {
      headline: 'Premium {{GAME_NAME}} Hosting',
      subheadline: 'Experience lag-free gaming with our high-performance servers',
      buttonText: 'Get Started',
      buttonUrl: '/order',
      backgroundImage: '',
      videoUrl: '',
      features: ['24/7 Support', 'DDoS Protection', 'Instant Setup'],
      showStats: true,
      stats: [
        { label: 'Players Online', value: '{{PLAYER_COUNT}}' },
        { label: 'Uptime', value: '99.9%' },
        { label: 'Servers', value: '1000+' }
      ]
    },
    style: {
      backgroundColor: '#0a0a0a',
      textColor: '#ffffff',
      padding: '4rem',
      layout: 'center'
    }
  },
  features: {
    type: 'features',
    title: 'Features Section',
    content: {
      headline: 'Why Choose Our {{GAME_NAME}} Servers?',
      subheadline: 'Discover the advantages that set us apart',
      features: [
        { title: 'High Performance', description: 'Latest hardware for optimal gaming', icon: 'monitor' },
        { title: '24/7 Support', description: 'Expert support whenever you need it', icon: 'users' },
        { title: 'Easy Setup', description: 'Get your server running in minutes', icon: 'settings' },
        { title: 'DDoS Protection', description: 'Advanced security for uninterrupted gameplay', icon: 'shield' },
        { title: 'Automatic Backups', description: 'Your data is safe with daily backups', icon: 'database' },
        { title: 'Performance Monitoring', description: 'Real-time server metrics and alerts', icon: 'monitor' },
        { title: 'One-Click Modpacks', description: 'Install popular modpacks instantly', icon: 'package' },
        { title: 'Global Locations', description: 'Servers in multiple regions worldwide', icon: 'cloud' },
        { title: 'Advanced Control Panel', description: 'User-friendly management interface', icon: 'wrench' },
        { title: 'Plugin Support', description: 'Customize with thousands of plugins', icon: 'plugin' }
      ]
    },
    style: {
      backgroundColor: '#1a1a1a',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'grid'
    }
  },
  pricing: {
    type: 'pricing',
    title: 'Pricing Section',
    content: {
      headline: '{{GAME_NAME}} Server Plans',
      subheadline: 'Choose the perfect plan for your community',
      plans: [
        { name: 'Starter', price: '{{BASE_PRICE}}', originalPrice: '', features: ['4GB RAM', '10 Players', 'Basic Support', '10GB Storage'], highlight: false, buttonText: 'Get Started' },
        { name: 'Pro', price: '{{BASE_PRICE * 2}}', originalPrice: '', features: ['8GB RAM', '25 Players', 'Priority Support', '25GB Storage', 'Plugin Support'], highlight: true, buttonText: 'Most Popular' },
        { name: 'Enterprise', price: '{{BASE_PRICE * 3}}', originalPrice: '', features: ['16GB RAM', 'Unlimited Players', '24/7 Support', '100GB Storage', 'Full Management'], highlight: false, buttonText: 'Contact Us' }
      ]
    },
    style: {
      backgroundColor: '#0f0f0f',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'cards'
    }
  },
  gallery: {
    type: 'gallery',
    title: 'Screenshots Gallery',
    content: {
      headline: '{{GAME_NAME}} in Action',
      subheadline: 'See what players are building on our servers',
      images: [
        { url: '/images/gallery/screenshot1.jpg', title: 'Epic Build', description: 'Amazing player creation' },
        { url: '/images/gallery/screenshot2.jpg', title: 'Adventure Time', description: 'Exploring new worlds' },
        { url: '/images/gallery/screenshot3.jpg', title: 'Community Event', description: 'Players having fun together' }
      ]
    },
    style: {
      backgroundColor: '#1a1a1a',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'masonry'
    }
  },
  testimonials: {
    type: 'testimonials',
    title: 'Player Reviews',
    content: {
      headline: 'What Players Say About Us',
      subheadline: 'Join thousands of satisfied customers',
      testimonials: [
        { name: 'Alex Johnson', rating: 5, comment: 'Best server hosting I\'ve used. Great performance and support!', avatar: '', title: 'Server Owner' },
        { name: 'Sarah Chen', rating: 5, comment: 'Setup was incredibly easy. Had my server running in minutes!', avatar: '', title: 'Community Leader' },
        { name: 'Mike Davis', rating: 5, comment: 'Outstanding uptime and customer service. Highly recommend!', avatar: '', title: 'Gaming Streamer' }
      ]
    },
    style: {
      backgroundColor: '#0a0a0a',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'carousel'
    }
  },
  faq: {
    type: 'faq',
    title: 'Frequently Asked Questions',
    content: {
      headline: 'Common Questions About {{GAME_NAME}} Hosting',
      subheadline: 'Everything you need to know',
      faqs: [
        { question: 'How quickly can I get my server online?', answer: 'Your server will be ready within minutes of completing your order. Our automated setup process ensures instant deployment.' },
        { question: 'Do you provide technical support?', answer: 'Yes! We offer 24/7 technical support through live chat, tickets, and our knowledge base.' },
        { question: 'Can I install plugins and mods?', answer: 'Absolutely! You have full control over your server and can install any compatible plugins or mods.' }
      ]
    },
    style: {
      backgroundColor: '#1a1a1a',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'accordion'
    }
  },
  cta: {
    type: 'cta',
    title: 'Call to Action',
    content: {
      headline: 'Ready to Start Your {{GAME_NAME}} Server?',
      subheadline: 'Join thousands of players already enjoying lag-free gaming',
      buttonText: 'Start Now',
      buttonUrl: '/order',
      secondaryButtonText: 'View Plans',
      secondaryButtonUrl: '#pricing',
      backgroundImage: ''
    },
    style: {
      backgroundColor: '#00ff88',
      textColor: '#000000',
      padding: '4rem',
      layout: 'center'
    }
  },
  specs: {
    type: 'specs',
    title: 'Server Specifications',
    content: {
      headline: 'Powerful Hardware for {{GAME_NAME}}',
      subheadline: 'Enterprise-grade infrastructure for the best gaming experience',
      specs: [
        { category: 'CPU', items: ['Intel Xeon E5-2697 v3', '14 Cores @ 2.6GHz', 'Turbo Boost up to 3.6GHz'] },
        { category: 'Memory', items: ['DDR4 ECC RAM', 'Up to 128GB per server', 'High-speed memory modules'] },
        { category: 'Storage', items: ['NVMe SSD Storage', 'RAID 1 Configuration', 'Daily automated backups'] },
        { category: 'Network', items: ['1Gbps dedicated bandwidth', 'DDoS protection included', 'Multiple datacenter locations'] }
      ]
    },
    style: {
      backgroundColor: '#0f0f0f',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'table'
    }
  },
  'game-features': {
    type: 'game-features',
    title: 'Game-Specific Features',
    content: {
      headline: '{{GAME_NAME}}-Specific Features',
      subheadline: 'Optimized hosting for the best {{GAME_NAME}} experience',
      features: [
        { icon: 'Package', title: 'Plugin Support', description: 'Easy installation and management of game-specific plugins' },
        { icon: 'Settings', title: 'Server Config', description: 'Full access to configuration files and settings' },
        { icon: 'Globe', title: 'World Management', description: 'Upload custom worlds and manage backups easily' }
      ]
    },
    style: {
      backgroundColor: '#0f0f0f',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'grid'
    }
  },
  requirements: {
    type: 'requirements',
    title: 'System Requirements',
    content: {
      headline: '{{GAME_NAME}} Server Setup',
      subheadline: 'Everything you need to know to get started',
      requirements: [
        { component: 'RAM', requirement: 'Minimum 2GB, Recommended 4GB+ for optimal performance' },
        { component: 'CPU', requirement: '2+ CPU cores for smooth gameplay' },
        { component: 'Storage', requirement: '10GB+ SSD space for maps and saves' },
        { component: 'Network', requirement: 'Stable internet connection for player connectivity' }
      ]
    },
    style: {
      backgroundColor: '#1a1a1a',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'split'
    }
  },
  'setup-steps': {
    type: 'setup-steps',
    title: 'Setup Guide',
    content: {
      headline: 'Quick Setup Guide',
      subheadline: 'Get your {{GAME_NAME}} server running in minutes',
      steps: [
        { title: 'Choose Server Type', description: 'Select the best server configuration for your needs' },
        { title: 'Configure Settings', description: 'Set world name, game mode, and player limits' },
        { title: 'Launch & Connect', description: 'Start your server and share the IP with friends' }
      ]
    },
    style: {
      backgroundColor: '#1a1a1a',
      textColor: '#ffffff',
      padding: '3rem',
      layout: 'split'
    }
  }
};

export default function AdminGameCustomization() {
  const [match, params] = useRoute('/admin/games/:gameId/customize');
  const gameId = params?.gameId;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch game data with proper error handling and fallback
  const { data: game, isLoading: gameLoading, error: gameError } = useQuery<Game>({
    queryKey: ['/api/games', gameId],
    enabled: !!gameId,
    queryFn: async () => {
      // First try to get game from the general games API
      try {
        const response = await fetch(`/api/games/${gameId}`);
        if (response.ok) {
          return response.json();
        }
      } catch (error) {
        console.log('Failed to fetch individual game, trying from games list');
      }
      
      // Fallback: get all games and find the one we need
      const allGamesResponse = await fetch('/api/games');
      if (!allGamesResponse.ok) {
        throw new Error('Failed to fetch games data');
      }
      
      const allGames = await allGamesResponse.json();
      const foundGame = allGames.find((g: any) => g.id === gameId);
      
      if (!foundGame) {
        throw new Error('Game not found');
      }
      
      return foundGame;
    },
    retry: 2,
    staleTime: 0,
  });

  // Page builder state
  const [sections, setSections] = useState<PageSection[]>([]);
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [draggedComponent, setDraggedComponent] = useState<string | null>(null);

  // Initialize sections from game data
  useEffect(() => {
    if (game && sections.length === 0) {
      // Try to parse existing page structure or create default
      try {
        const pageData = game.pageStructure ? JSON.parse(game.pageStructure) : null;
        if (pageData && pageData.sections) {
          setSections(pageData.sections);
        } else {
          // Create default page structure
          const defaultHero = {
            ...defaultSections.hero,
            id: 'hero-1',
            order: 0,
            content: {
              ...defaultSections.hero.content,
              headline: `Premium ${game.name} Hosting`,
              subheadline: `Experience lag-free ${game.name} gaming with our high-performance servers`
            }
          };
          setSections([defaultHero]);
        }
      } catch (error) {
        // Fallback to default structure
        const defaultHero = {
          ...defaultSections.hero,
          id: 'hero-1',
          order: 0,
          content: {
            ...defaultSections.hero.content,
            headline: `Premium ${game?.name || 'Game'} Hosting`,
            subheadline: `Experience lag-free ${game?.name || 'game'} gaming with our high-performance servers`
          }
        };
        setSections([defaultHero]);
      }
    }
  }, [game, sections.length]);

  // Page builder functions
  const addSection = (type: string) => {
    const template = defaultSections[type];
    if (!template) return;

    const newSection: PageSection = {
      ...template,
      id: `${type}-${Date.now()}`,
      order: sections.length
    };
    setSections([...sections, newSection]);
    setSelectedSection(newSection.id);
  };

  const updateSection = (sectionId: string, updates: Partial<PageSection>) => {
    setSections(current => current.map(section => 
      section.id === sectionId ? { ...section, ...updates } : section
    ));
  };

  const updateSectionContent = (sectionId: string, contentUpdates: any) => {
    setSections(current => current.map(section => 
      section.id === sectionId 
        ? { ...section, content: { ...section.content, ...contentUpdates } }
        : section
    ));
  };

  const updateSectionStyle = (sectionId: string, styleUpdates: any) => {
    setSections(current => current.map(section => 
      section.id === sectionId 
        ? { ...section, style: { ...section.style, ...styleUpdates } }
        : section
    ));
  };

  const deleteSection = (sectionId: string) => {
    setSections(sections.filter(section => section.id !== sectionId));
    if (selectedSection === sectionId) {
      setSelectedSection(null);
    }
  };

  const moveSection = (sectionId: string, direction: 'up' | 'down') => {
    const sectionIndex = sections.findIndex(s => s.id === sectionId);
    if (sectionIndex === -1) return;

    const newSections = [...sections];
    const targetIndex = direction === 'up' ? sectionIndex - 1 : sectionIndex + 1;
    
    if (targetIndex < 0 || targetIndex >= newSections.length) return;

    [newSections[sectionIndex], newSections[targetIndex]] = [newSections[targetIndex], newSections[sectionIndex]];
    
    // Update order values
    newSections.forEach((section, index) => {
      section.order = index;
    });

    setSections(newSections);
  };

  // API request helper function for admin operations
  const makeApiRequest = async (url: string, options: RequestInit = {}) => {
    const token = localStorage.getItem("adminToken");
    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
        ...options.headers,
      },
    });

    if (response.status === 401) {
      localStorage.removeItem("adminToken");
      localStorage.removeItem("adminUser");
      throw new Error("Unauthorized");
    }

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || "Request failed");
    }

    return response.json();
  };

  // Save page structure mutation
  const savePageMutation = useMutation({
    mutationFn: async () => {
      const pageStructure = JSON.stringify({ sections });
      
      return makeApiRequest(`/api/admin/games/${gameId}`, {
        method: 'PUT',
        body: JSON.stringify({
          ...game,
          pageStructure
        }),
      });
    },
    onSuccess: () => {
      // Invalidate all related game queries to ensure updates are reflected
      queryClient.invalidateQueries({ queryKey: ['/api/games', gameId] });
      queryClient.invalidateQueries({ queryKey: ['/api/games'] });
      queryClient.invalidateQueries({ queryKey: ['/api/games', game?.slug] }); 
      // Refresh the current query immediately to show updated data
      queryClient.refetchQueries({ queryKey: ['/api/games', gameId] });
      toast({ title: 'Page structure saved successfully! Changes will appear on the game page.' });
    },
    onError: (error: Error) => {
      toast({ title: 'Failed to save page structure', description: error.message, variant: 'destructive' });
    },
  });

  // Component preview renderer
  const renderSectionPreview = (section: PageSection) => {
    const style = {
      backgroundColor: section.style.backgroundColor,
      color: section.style.textColor,
      padding: section.style.padding === '4rem' ? '2rem' : '1rem',
    };

    switch (section.type) {
      case 'hero':
        return (
          <div style={style} className="text-center">
            <h1 className="text-3xl font-bold mb-4">{section.content.headline}</h1>
            <p className="text-xl mb-6">{section.content.subheadline}</p>
            <Button className="bg-gaming-green text-gaming-black">
              {section.content.buttonText}
            </Button>
          </div>
        );
      case 'features':
        return (
          <div style={style}>
            <h2 className="text-2xl font-bold mb-6 text-center">{section.content.headline}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {section.content.features.map((feature: any, index: number) => (
                <div key={index} className="text-center">
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p>{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        );
      case 'pricing':
        return (
          <div style={style}>
            <h2 className="text-2xl font-bold mb-6 text-center">{section.content.headline}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {section.content.plans.map((plan: any, index: number) => (
                <div key={index} className="border border-gaming-green/20 rounded-lg p-4">
                  <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                  <p className="text-2xl font-bold mb-4">${plan.price}/mo</p>
                  <ul className="space-y-2">
                    {plan.features.map((feature: string, i: number) => (
                      <li key={i} className="text-sm">✓ {feature}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        );
      case 'gallery':
        return (
          <div style={style}>
            <h2 className="text-2xl font-bold mb-6 text-center">{section.content.headline}</h2>
            <p className="text-center mb-8 opacity-80">{section.content.subheadline}</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {section.content.images.map((img: any, index: number) => (
                <div key={index} className="rounded-lg overflow-hidden bg-gaming-green/10 p-4">
                  <div className="aspect-video bg-gaming-green/20 rounded mb-2 flex items-center justify-center">
                    <ImageIcon className="w-8 h-8 text-gaming-green/50" />
                  </div>
                  <h3 className="font-semibold">{img.title}</h3>
                  <p className="text-sm opacity-70">{img.description}</p>
                </div>
              ))}
            </div>
          </div>
        );
      case 'testimonials':
        return (
          <div style={style}>
            <h2 className="text-2xl font-bold mb-6 text-center">{section.content.headline}</h2>
            <p className="text-center mb-8 opacity-80">{section.content.subheadline}</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {section.content.testimonials.map((testimonial: any, index: number) => (
                <div key={index} className="border border-gaming-green/20 rounded-lg p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gaming-green/20 rounded-full flex items-center justify-center mr-3">
                      <Users className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-sm opacity-70">{testimonial.title}</p>
                    </div>
                  </div>
                  <div className="flex mb-2">
                    {Array.from({length: testimonial.rating}).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-gaming-green text-gaming-green" />
                    ))}
                  </div>
                  <p className="italic">"{testimonial.comment}"</p>
                </div>
              ))}
            </div>
          </div>
        );
      case 'faq':
        return (
          <div style={style}>
            <h2 className="text-2xl font-bold mb-6 text-center">{section.content.headline}</h2>
            <p className="text-center mb-8 opacity-80">{section.content.subheadline}</p>
            <div className="max-w-3xl mx-auto space-y-4">
              {section.content.faqs.map((faq: any, index: number) => (
                <div key={index} className="border border-gaming-green/20 rounded-lg">
                  <div className="p-4 border-b border-gaming-green/10">
                    <h3 className="font-semibold flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-gaming-green" />
                      {faq.question}
                    </h3>
                  </div>
                  <div className="p-4">
                    <p className="opacity-80">{faq.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'cta':
        return (
          <div style={style} className="text-center">
            <h2 className="text-3xl font-bold mb-4">{section.content.headline}</h2>
            <p className="text-xl mb-8">{section.content.subheadline}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-current text-black" size="lg">
                {section.content.buttonText}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              {section.content.secondaryButtonText && (
                <Button variant="outline" size="lg" className="border-current text-current">
                  {section.content.secondaryButtonText}
                </Button>
              )}
            </div>
          </div>
        );
      case 'specs':
        return (
          <div style={style}>
            <h2 className="text-2xl font-bold mb-6 text-center">{section.content.headline}</h2>
            <p className="text-center mb-8 opacity-80">{section.content.subheadline}</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {section.content.specs.map((spec: any, index: number) => (
                <div key={index} className="border border-gaming-green/20 rounded-lg p-4">
                  <h3 className="font-bold text-gaming-green mb-3 flex items-center gap-2">
                    <Monitor className="w-5 h-5" />
                    {spec.category}
                  </h3>
                  <ul className="space-y-2">
                    {spec.items.map((item: string, i: number) => (
                      <li key={i} className="text-sm opacity-80">• {item}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        );
      default:
        return (
          <div style={style} className="text-center py-8">
            <p>Section: {section.title}</p>
          </div>
        );
    }
  };

  if (gameLoading) {
    return (
      <div className="min-h-screen bg-gaming-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gaming-green mb-4"></div>
          <p className="text-gaming-gray">Loading game data...</p>
        </div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen bg-gaming-black text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gaming-green mb-4">Game Not Found</h2>
          <p className="text-gaming-gray mb-6">The game you're looking for doesn't exist.</p>
          <Link href="/admin">
            <Button className="bg-gaming-green text-gaming-black">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Admin
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-panel min-h-screen bg-gaming-black text-white">
      {/* Header */}
      <div className="border-b border-gaming-green/20 bg-gaming-dark">
        <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <Layout className="w-6 h-6 sm:w-8 sm:h-8 text-gaming-green" />
            <div>
              <h1 className="text-xl sm:text-2xl font-bold">Page Builder - {game.name}</h1>
              <p className="text-xs sm:text-sm text-gray-400">Drag and drop components to build your game page</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
            <div className="flex items-center space-x-2">
              <Switch 
                checked={previewMode}
                onCheckedChange={setPreviewMode}
                id="preview-mode"
              />
              <Label htmlFor="preview-mode" className="text-xs sm:text-sm text-gray-300">
                {previewMode ? <Eye className="w-3 h-3 sm:w-4 sm:h-4 inline mr-1" /> : <EyeOff className="w-3 h-3 sm:w-4 sm:h-4 inline mr-1" />}
                <span className="hidden sm:inline">Preview</span>
              </Label>
            </div>
            <Button
              onClick={() => savePageMutation.mutate()}
              disabled={savePageMutation.isPending}
              className="bg-gaming-green hover:bg-gaming-green/90 text-gaming-black text-sm sm:text-base w-full sm:w-auto"
            >
              <Save className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
              Save Page
            </Button>
            <Link href="/admin" className="w-full sm:w-auto">
              <Button variant="outline" className="border-gaming-green/30 text-gaming-green text-sm sm:text-base w-full">
                <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                Back
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content - Page Builder */}
      <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-6">
        <div className="page-builder">
          {/* Component Palette */}
          <div className="component-palette">
            <h3 className="text-lg font-semibold text-gaming-green mb-4 flex items-center gap-2">
              <Package className="w-5 h-5" />
              Components
            </h3>
            <div className="grid grid-cols-1 gap-2">
              {Object.entries(defaultSections).map(([key, section]) => (
                <Button
                  key={key}
                  onClick={() => addSection(key)}
                  className="w-full justify-start bg-gaming-black-lighter border-gaming-green/30 text-gaming-green hover:bg-gaming-green/10 p-3 h-auto"
                >
                  <div className="flex items-center gap-3">
                    {key === 'hero' && <Layout className="w-4 h-4" />}
                    {key === 'features' && <Star className="w-4 h-4" />}
                    {key === 'pricing' && <DollarSign className="w-4 h-4" />}
                    {key === 'gallery' && <ImageIcon className="w-4 h-4" />}
                    {key === 'testimonials' && <Users className="w-4 h-4" />}
                    {key === 'faq' && <HelpCircle className="w-4 h-4" />}
                    {key === 'cta' && <ArrowRight className="w-4 h-4" />}
                    {key === 'specs' && <Monitor className="w-4 h-4" />}
                    {key === 'game-features' && <Package className="w-4 h-4" />}
                    {key === 'requirements' && <FileText className="w-4 h-4" />}
                    {key === 'setup-steps' && <Settings className="w-4 h-4" />}
                    <div className="text-left">
                      <div className="font-medium text-sm">{section.title}</div>
                      <div className="text-xs text-gray-400 capitalize">{key}</div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Page Canvas */}
          <div className="page-canvas">
            <div className="p-4">
              <div className="text-center mb-6">
                <h2 className="text-xl font-bold text-gaming-green mb-2">
                  {game.name} Game Page Preview
                </h2>
                <p className="text-sm text-gray-400">
                  {sections.length} section{sections.length !== 1 ? 's' : ''} • Click to edit
                </p>
              </div>

              {sections.length === 0 ? (
                <div className="drop-zone">
                  <div className="text-center text-gray-400">
                    <Layout className="w-12 h-12 mx-auto mb-3" />
                    <p className="text-lg font-medium mb-2">Start Building Your Page</p>
                    <p className="text-sm">Click on components from the left panel to add them here</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {sections
                    .sort((a, b) => a.order - b.order)
                    .map((section) => (
                      <div
                        key={section.id}
                        className={`section-component ${selectedSection === section.id ? 'selected' : ''}`}
                        onClick={() => setSelectedSection(section.id)}
                      >
                        <div className="section-controls">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              moveSection(section.id, 'up');
                            }}
                            className="w-8 h-8 p-0 border-gaming-green/30 text-gaming-green hover:bg-gaming-green/10"
                          >
                            <ChevronUp className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              moveSection(section.id, 'down');
                            }}
                            className="w-8 h-8 p-0 border-gaming-green/30 text-gaming-green hover:bg-gaming-green/10"
                          >
                            <ChevronDown className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteSection(section.id);
                            }}
                            className="w-8 h-8 p-0 border-red-500/30 text-red-400 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        {renderSectionPreview(section)}
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>

          {/* Properties Panel */}
          <div className="properties-panel">
            <h3 className="text-lg font-semibold text-gaming-green mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Properties
            </h3>
            
            {selectedSection ? (
              <SectionEditor
                section={sections.find(s => s.id === selectedSection)!}
                onUpdate={(updates) => updateSection(selectedSection, updates)}
                onUpdateContent={(contentUpdates) => updateSectionContent(selectedSection, contentUpdates)}
                onUpdateStyle={(styleUpdates) => updateSectionStyle(selectedSection, styleUpdates)}
                game={game}
              />
            ) : (
              <div className="text-center text-gray-400 py-8">
                <Settings className="w-12 h-12 mx-auto mb-3" />
                <p className="text-sm">Select a section to edit its properties</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Section Editor Component
interface SectionEditorProps {
  section: PageSection;
  onUpdate: (updates: Partial<PageSection>) => void;
  onUpdateContent: (contentUpdates: any) => void;
  onUpdateStyle: (styleUpdates: any) => void;
  game: Game;
}

function SectionEditor({ section, onUpdate, onUpdateContent, onUpdateStyle, game }: SectionEditorProps) {
  const updateContent = (contentUpdates: any) => {
    onUpdateContent(contentUpdates);
  };

  const updateStyle = (styleUpdates: any) => {
    onUpdateStyle(styleUpdates);
  };

  return (
    <div className="space-y-6">
      {/* Section Title */}
      <div>
        <Label className="text-gray-300">Section Title</Label>
        <Input
          value={section.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          className="admin-input mt-1"
        />
      </div>

      {/* Content Editor based on section type */}
      {section.type === 'hero' && (
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-gaming-green">Hero Content</h4>
          <div>
            <Label className="text-gray-300">Headline</Label>
            <Input
              value={section.content.headline}
              onChange={(e) => updateContent({ headline: e.target.value })}
              className="admin-input mt-1"
              placeholder="Premium {{GAME_NAME}} Hosting"
            />
          </div>
          <div>
            <Label className="text-gray-300">Subheadline</Label>
            <Textarea
              value={section.content.subheadline}
              onChange={(e) => updateContent({ subheadline: e.target.value })}
              className="admin-textarea mt-1"
              rows={2}
            />
          </div>
          <div>
            <Label className="text-gray-300">Button Text</Label>
            <Input
              value={section.content.buttonText}
              onChange={(e) => updateContent({ buttonText: e.target.value })}
              className="admin-input mt-1"
            />
          </div>
        </div>
      )}

      {section.type === 'features' && (
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-gaming-green">Features Content</h4>
          <div>
            <Label className="text-gray-300">Headline</Label>
            <Input
              value={section.content.headline}
              onChange={(e) => updateContent({ headline: e.target.value })}
              className="admin-input mt-1"
            />
          </div>
          <div>
            <Label className="text-gray-300">Features</Label>
            <div className="space-y-2 mt-2">
              {section.content.features.map((feature: any, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={feature.title}
                    onChange={(e) => {
                      const newFeatures = [...section.content.features];
                      newFeatures[index] = { ...feature, title: e.target.value };
                      updateContent({ features: newFeatures });
                    }}
                    className="admin-input flex-1"
                    placeholder="Feature title"
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const newFeatures = section.content.features.filter((_: any, i: number) => i !== index);
                      updateContent({ features: newFeatures });
                    }}
                    className="border-red-500/30 text-red-400 hover:bg-red-500/10 px-3"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              <Button
                size="sm"
                onClick={() => {
                  const newFeatures = [...section.content.features, { title: 'New Feature', description: 'Feature description', icon: 'star' }];
                  updateContent({ features: newFeatures });
                }}
                className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30 w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Feature
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Content Editor with Tabs */}
      <Tabs defaultValue="content" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-gaming-black border-gaming-green/30">
          <TabsTrigger value="content" className="data-[state=active]:bg-gaming-green/20">
            <Type className="w-4 h-4 mr-2" />
            Content
          </TabsTrigger>
          <TabsTrigger value="style" className="data-[state=active]:bg-gaming-green/20">
            <Palette className="w-4 h-4 mr-2" />
            Style
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="content" className="space-y-4 mt-4">
          {/* Dynamic content editor based on section type */}
          {section.type === 'hero' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Premium Game Hosting"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Textarea
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-textarea mt-1"
                  rows={2}
                  placeholder="Experience lag-free gaming..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Button Text</Label>
                  <Input
                    value={section.content.buttonText || ''}
                    onChange={(e) => updateContent({ buttonText: e.target.value })}
                    className="admin-input mt-1"
                    placeholder="Get Started"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Button URL</Label>
                  <Input
                    value={section.content.buttonUrl || ''}
                    onChange={(e) => updateContent({ buttonUrl: e.target.value })}
                    className="admin-input mt-1"
                    placeholder="/order"
                  />
                </div>
              </div>
              <div>
                <Label className="text-gray-300">Background Image URL</Label>
                <Input
                  value={section.content.backgroundImage || ''}
                  onChange={(e) => updateContent({ backgroundImage: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
          )}

          {section.type === 'features' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Why Choose Our Servers?"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Discover the advantages..."
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Features</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newFeatures = [...(section.content.features || []), { title: 'New Feature', description: 'Feature description', icon: 'star' }];
                      updateContent({ features: newFeatures });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Feature
                  </Button>
                </div>
                <div className="space-y-2">
                  {(section.content.features || []).map((feature: any, index: number) => (
                    <div key={index} className="grid grid-cols-2 gap-2">
                      <Input
                        value={feature.title || ''}
                        onChange={(e) => {
                          const newFeatures = [...section.content.features];
                          newFeatures[index] = { ...feature, title: e.target.value };
                          updateContent({ features: newFeatures });
                        }}
                        className="admin-input"
                        placeholder="Feature title"
                      />
                      <div className="flex gap-2">
                        <Input
                          value={feature.description || ''}
                          onChange={(e) => {
                            const newFeatures = [...section.content.features];
                            newFeatures[index] = { ...feature, description: e.target.value };
                            updateContent({ features: newFeatures });
                          }}
                          className="admin-input"
                          placeholder="Feature description"
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newFeatures = section.content.features.filter((_: any, i: number) => i !== index);
                            updateContent({ features: newFeatures });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {section.type === 'pricing' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Server Plans"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Choose the perfect plan..."
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Plans</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newPlans = [...(section.content.plans || []), { name: 'New Plan', price: '$9.99', features: ['Feature 1', 'Feature 2'], highlight: false, buttonText: 'Get Started' }];
                      updateContent({ plans: newPlans });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Plan
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.plans || []).map((plan: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="grid grid-cols-2 gap-2 flex-1">
                          <Input
                            value={plan.name || ''}
                            onChange={(e) => {
                              const newPlans = [...section.content.plans];
                              newPlans[index] = { ...plan, name: e.target.value };
                              updateContent({ plans: newPlans });
                            }}
                            placeholder="Plan name"
                            className="admin-input"
                          />
                          <Input
                            value={plan.price || ''}
                            onChange={(e) => {
                              const newPlans = [...section.content.plans];
                              newPlans[index] = { ...plan, price: e.target.value };
                              updateContent({ plans: newPlans });
                            }}
                            placeholder="$9.99"
                            className="admin-input"
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newPlans = section.content.plans.filter((_: any, i: number) => i !== index);
                            updateContent({ plans: newPlans });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <Textarea
                        value={Array.isArray(plan.features) ? plan.features.join('\n') : ''}
                        onChange={(e) => {
                          const newPlans = [...section.content.plans];
                          newPlans[index] = { ...plan, features: e.target.value.split('\n').filter(f => f.trim()) };
                          updateContent({ plans: newPlans });
                        }}
                        placeholder="Feature 1&#10;Feature 2&#10;Feature 3"
                        className="admin-textarea"
                        rows={3}
                      />
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Gallery Section Editor */}
          {section.type === 'gallery' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Game Screenshots"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="See what players are building..."
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Images</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newImages = [...(section.content.images || []), { url: '', title: 'New Image', description: 'Image description' }];
                      updateContent({ images: newImages });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Image
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.images || []).map((image: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="grid grid-cols-1 gap-2 flex-1">
                          <Input
                            value={image.url || ''}
                            onChange={(e) => {
                              const newImages = [...section.content.images];
                              newImages[index] = { ...image, url: e.target.value };
                              updateContent({ images: newImages });
                            }}
                            placeholder="Image URL"
                            className="admin-input"
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <Input
                              value={image.title || ''}
                              onChange={(e) => {
                                const newImages = [...section.content.images];
                                newImages[index] = { ...image, title: e.target.value };
                                updateContent({ images: newImages });
                              }}
                              placeholder="Image title"
                              className="admin-input"
                            />
                            <Input
                              value={image.description || ''}
                              onChange={(e) => {
                                const newImages = [...section.content.images];
                                newImages[index] = { ...image, description: e.target.value };
                                updateContent({ images: newImages });
                              }}
                              placeholder="Image description"
                              className="admin-input"
                            />
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newImages = section.content.images.filter((_: any, i: number) => i !== index);
                            updateContent({ images: newImages });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Testimonials Section Editor */}
          {section.type === 'testimonials' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="What Players Say"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Join thousands of satisfied customers"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Testimonials</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newTestimonials = [...(section.content.testimonials || []), { name: 'New Customer', rating: 5, comment: 'Great service!', avatar: '', title: 'Server Owner' }];
                      updateContent({ testimonials: newTestimonials });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Testimonial
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.testimonials || []).map((testimonial: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="grid grid-cols-2 gap-2 flex-1">
                          <Input
                            value={testimonial.name || ''}
                            onChange={(e) => {
                              const newTestimonials = [...section.content.testimonials];
                              newTestimonials[index] = { ...testimonial, name: e.target.value };
                              updateContent({ testimonials: newTestimonials });
                            }}
                            placeholder="Customer name"
                            className="admin-input"
                          />
                          <Input
                            value={testimonial.title || ''}
                            onChange={(e) => {
                              const newTestimonials = [...section.content.testimonials];
                              newTestimonials[index] = { ...testimonial, title: e.target.value };
                              updateContent({ testimonials: newTestimonials });
                            }}
                            placeholder="Customer title"
                            className="admin-input"
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newTestimonials = section.content.testimonials.filter((_: any, i: number) => i !== index);
                            updateContent({ testimonials: newTestimonials });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <Textarea
                        value={testimonial.comment || ''}
                        onChange={(e) => {
                          const newTestimonials = [...section.content.testimonials];
                          newTestimonials[index] = { ...testimonial, comment: e.target.value };
                          updateContent({ testimonials: newTestimonials });
                        }}
                        placeholder="Customer testimonial..."
                        className="admin-textarea mb-2"
                        rows={2}
                      />
                      <Select
                        value={testimonial.rating?.toString() || '5'}
                        onValueChange={(value) => {
                          const newTestimonials = [...section.content.testimonials];
                          newTestimonials[index] = { ...testimonial, rating: parseInt(value) };
                          updateContent({ testimonials: newTestimonials });
                        }}
                      >
                        <SelectTrigger className="admin-input">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 Star</SelectItem>
                          <SelectItem value="2">2 Stars</SelectItem>
                          <SelectItem value="3">3 Stars</SelectItem>
                          <SelectItem value="4">4 Stars</SelectItem>
                          <SelectItem value="5">5 Stars</SelectItem>
                        </SelectContent>
                      </Select>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* FAQ Section Editor */}
          {section.type === 'faq' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Frequently Asked Questions"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Everything you need to know"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">FAQs</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newFaqs = [...(section.content.faqs || []), { question: 'New Question', answer: 'Answer to the question...' }];
                      updateContent({ faqs: newFaqs });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add FAQ
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.faqs || []).map((faq: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <Input
                            value={faq.question || ''}
                            onChange={(e) => {
                              const newFaqs = [...section.content.faqs];
                              newFaqs[index] = { ...faq, question: e.target.value };
                              updateContent({ faqs: newFaqs });
                            }}
                            placeholder="Question"
                            className="admin-input mb-2"
                          />
                          <Textarea
                            value={faq.answer || ''}
                            onChange={(e) => {
                              const newFaqs = [...section.content.faqs];
                              newFaqs[index] = { ...faq, answer: e.target.value };
                              updateContent({ faqs: newFaqs });
                            }}
                            placeholder="Answer"
                            className="admin-textarea"
                            rows={3}
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newFaqs = section.content.faqs.filter((_: any, i: number) => i !== index);
                            updateContent({ faqs: newFaqs });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CTA Section Editor */}
          {section.type === 'cta' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Ready to Start?"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Join thousands of players..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Primary Button Text</Label>
                  <Input
                    value={section.content.buttonText || ''}
                    onChange={(e) => updateContent({ buttonText: e.target.value })}
                    className="admin-input mt-1"
                    placeholder="Start Now"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Primary Button URL</Label>
                  <Input
                    value={section.content.buttonUrl || ''}
                    onChange={(e) => updateContent({ buttonUrl: e.target.value })}
                    className="admin-input mt-1"
                    placeholder="/order"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Secondary Button Text</Label>
                  <Input
                    value={section.content.secondaryButtonText || ''}
                    onChange={(e) => updateContent({ secondaryButtonText: e.target.value })}
                    className="admin-input mt-1"
                    placeholder="View Plans"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Secondary Button URL</Label>
                  <Input
                    value={section.content.secondaryButtonUrl || ''}
                    onChange={(e) => updateContent({ secondaryButtonUrl: e.target.value })}
                    className="admin-input mt-1"
                    placeholder="#pricing"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Server Specs Section Editor */}
          {section.type === 'specs' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Server Specifications"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Enterprise-grade infrastructure..."
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Specifications</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newSpecs = [...(section.content.specs || []), { category: 'Hardware', items: ['Feature 1', 'Feature 2'] }];
                      updateContent({ specs: newSpecs });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Spec Category
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.specs || []).map((spec: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <Input
                            value={spec.category || ''}
                            onChange={(e) => {
                              const newSpecs = [...section.content.specs];
                              newSpecs[index] = { ...spec, category: e.target.value };
                              updateContent({ specs: newSpecs });
                            }}
                            placeholder="Category (e.g., CPU, Memory)"
                            className="admin-input mb-2"
                          />
                          <Textarea
                            value={Array.isArray(spec.items) ? spec.items.join('\n') : ''}
                            onChange={(e) => {
                              const newSpecs = [...section.content.specs];
                              newSpecs[index] = { ...spec, items: e.target.value.split('\n').filter(f => f.trim()) };
                              updateContent({ specs: newSpecs });
                            }}
                            placeholder="Spec Item 1&#10;Spec Item 2&#10;Spec Item 3"
                            className="admin-textarea"
                            rows={3}
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newSpecs = section.content.specs.filter((_: any, i: number) => i !== index);
                            updateContent({ specs: newSpecs });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Game-Specific Features Section Editor */}
          {section.type === 'game-features' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Game-Specific Features"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Optimized for the best gaming experience"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Features</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newFeatures = [...(section.content.features || []), { icon: 'Package', title: 'New Feature', description: 'Feature description' }];
                      updateContent({ features: newFeatures });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Feature
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.features || []).map((feature: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="grid grid-cols-1 gap-2 flex-1">
                          <Input
                            value={feature.title || ''}
                            onChange={(e) => {
                              const newFeatures = [...section.content.features];
                              newFeatures[index] = { ...feature, title: e.target.value };
                              updateContent({ features: newFeatures });
                            }}
                            placeholder="Feature title"
                            className="admin-input"
                          />
                          <Textarea
                            value={feature.description || ''}
                            onChange={(e) => {
                              const newFeatures = [...section.content.features];
                              newFeatures[index] = { ...feature, description: e.target.value };
                              updateContent({ features: newFeatures });
                            }}
                            placeholder="Feature description"
                            className="admin-textarea"
                            rows={2}
                          />
                          <Input
                            value={feature.icon || ''}
                            onChange={(e) => {
                              const newFeatures = [...section.content.features];
                              newFeatures[index] = { ...feature, icon: e.target.value };
                              updateContent({ features: newFeatures });
                            }}
                            placeholder="Icon name (e.g., Package, Wrench, Globe)"
                            className="admin-input"
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newFeatures = section.content.features.filter((_: any, i: number) => i !== index);
                            updateContent({ features: newFeatures });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Requirements Section Editor */}
          {section.type === 'requirements' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="System Requirements"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Everything you need to know"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Requirements</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newReqs = [...(section.content.requirements || []), { component: 'Component', requirement: 'Requirement details' }];
                      updateContent({ requirements: newReqs });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Requirement
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.requirements || []).map((req: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="grid grid-cols-1 gap-2 flex-1">
                          <Input
                            value={req.component || ''}
                            onChange={(e) => {
                              const newReqs = [...section.content.requirements];
                              newReqs[index] = { ...req, component: e.target.value };
                              updateContent({ requirements: newReqs });
                            }}
                            placeholder="Component (e.g., RAM, CPU, Storage)"
                            className="admin-input"
                          />
                          <Textarea
                            value={req.requirement || ''}
                            onChange={(e) => {
                              const newReqs = [...section.content.requirements];
                              newReqs[index] = { ...req, requirement: e.target.value };
                              updateContent({ requirements: newReqs });
                            }}
                            placeholder="Requirement details"
                            className="admin-textarea"
                            rows={2}
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newReqs = section.content.requirements.filter((_: any, i: number) => i !== index);
                            updateContent({ requirements: newReqs });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Setup Steps Section Editor */}
          {section.type === 'setup-steps' && (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Headline</Label>
                <Input
                  value={section.content.headline || ''}
                  onChange={(e) => updateContent({ headline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Quick Setup Guide"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subheadline</Label>
                <Input
                  value={section.content.subheadline || ''}
                  onChange={(e) => updateContent({ subheadline: e.target.value })}
                  className="admin-input mt-1"
                  placeholder="Get your server running in minutes"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-gray-300">Setup Steps</Label>
                  <Button
                    size="sm"
                    onClick={() => {
                      const newSteps = [...(section.content.steps || []), { title: 'Step Title', description: 'Step description' }];
                      updateContent({ steps: newSteps });
                    }}
                    className="bg-gaming-green/20 text-gaming-green hover:bg-gaming-green/30"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Step
                  </Button>
                </div>
                <div className="space-y-3">
                  {(section.content.steps || []).map((step: any, index: number) => (
                    <Card key={index} className="p-4 bg-gaming-black border-gaming-green/20">
                      <div className="flex justify-between items-start mb-3">
                        <div className="grid grid-cols-1 gap-2 flex-1">
                          <Input
                            value={step.title || ''}
                            onChange={(e) => {
                              const newSteps = [...section.content.steps];
                              newSteps[index] = { ...step, title: e.target.value };
                              updateContent({ steps: newSteps });
                            }}
                            placeholder="Step title"
                            className="admin-input"
                          />
                          <Textarea
                            value={step.description || ''}
                            onChange={(e) => {
                              const newSteps = [...section.content.steps];
                              newSteps[index] = { ...step, description: e.target.value };
                              updateContent({ steps: newSteps });
                            }}
                            placeholder="Step description"
                            className="admin-textarea"
                            rows={2}
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const newSteps = section.content.steps.filter((_: any, i: number) => i !== index);
                            updateContent({ steps: newSteps });
                          }}
                          className="border-red-500/30 text-red-400 hover:bg-red-500/10 ml-2 px-3"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="style" className="space-y-4 mt-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Background</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  type="color"
                  value={section.style.backgroundColor}
                  onChange={(e) => updateStyle({ backgroundColor: e.target.value })}
                  className="w-12 h-10 rounded border-gaming-green/30"
                />
                <Input
                  value={section.style.backgroundColor}
                  onChange={(e) => updateStyle({ backgroundColor: e.target.value })}
                  className="admin-input flex-1"
                  placeholder="#000000"
                />
              </div>
            </div>
            <div>
              <Label className="text-gray-300">Text Color</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  type="color"
                  value={section.style.textColor}
                  onChange={(e) => updateStyle({ textColor: e.target.value })}
                  className="w-12 h-10 rounded border-gaming-green/30"
                />
                <Input
                  value={section.style.textColor}
                  onChange={(e) => updateStyle({ textColor: e.target.value })}
                  className="admin-input flex-1"
                  placeholder="#ffffff"
                />
              </div>
            </div>
          </div>
          <div>
            <Label className="text-gray-300">Padding</Label>
            <Select value={section.style.padding} onValueChange={(value) => updateStyle({ padding: value })}>
              <SelectTrigger className="admin-input mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1rem">Small (1rem)</SelectItem>
                <SelectItem value="2rem">Medium (2rem)</SelectItem>
                <SelectItem value="3rem">Large (3rem)</SelectItem>
                <SelectItem value="4rem">Extra Large (4rem)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-gray-300">Layout</Label>
            <Select value={section.style.layout} onValueChange={(value) => updateStyle({ layout: value })}>
              <SelectTrigger className="admin-input mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="center">Center</SelectItem>
                <SelectItem value="left">Left Aligned</SelectItem>
                <SelectItem value="right">Right Aligned</SelectItem>
                <SelectItem value="grid">Grid Layout</SelectItem>
                <SelectItem value="cards">Card Layout</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}